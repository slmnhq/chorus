/* src/include/port/svr4.h */

/* nothing needed */
